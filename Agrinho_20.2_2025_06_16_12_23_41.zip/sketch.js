function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let tela = "inicio";
let btnX = 300, btnY = 250, btnW = 200, btnH = 50;
let tempo = 0;
let tratorX = -80;
let caminhaoX = -120;
let botaoReiniciar = false;
let plantas = [];

function setup() {
  createCanvas(800, 400);
  iniciarPlantas();
  textFont("Georgia");
}

function draw() {
  background(135, 206, 235);

  if (tela === "inicio") telaInicial();
  else if (tela === "campo") cenaCampo();
  else if (tela === "caminho") cenaCaminho();
  else if (tela === "cidade") cenaCidade();
  else if (tela === "festa") cenaFesta();
}

function telaInicial() {
  textAlign(CENTER);
  textSize(36);
  fill(34, 139, 34);
  text("Caminhos que se Encontram", width / 2, 100);

  drawBotao(btnX, btnY, btnW, btnH, "Iniciar Jornada");
}

function cenaCampo() {
  background(135, 206, 235);

  // Céu e sol
  fill(255, 223, 0);
  ellipse(100, 80, 80, 80);

  // Terra
  fill(139, 69, 19);
  rect(0, 300, width, 100);

  // Plantas com base de terra
  for (let i = 0; i < plantas.length; i++) {
    if (plantas[i].ativa) {
      fill(34, 139, 34);
      ellipse(plantas[i].x, plantas[i].y, 30, 30);
      stroke(0);
      line(plantas[i].x, plantas[i].y + 15, plantas[i].x, plantas[i].y + 30);
      noStroke();
    }
  }

  // Trator
  drawTrator(tratorX, 270);
  tratorX += 2;

  // Colheita
  for (let i = 0; i < plantas.length; i++) {
    if (plantas[i].ativa && tratorX + 70 > plantas[i].x - 15 && tratorX < plantas[i].x + 15) {
      plantas[i].ativa = false;
    }
  }

  fill(255);
  textSize(18);
  textAlign(CENTER);
  text("No campo, a vida nasce, cresce e é colhida com sabedoria.", width / 2, 40);

  if (tratorX > width + 80) {
    tela = "caminho";
    caminhaoX = -100;
    tempo = millis();
  }
}

function iniciarPlantas() {
  plantas = [];
  for (let i = 0; i < width; i += 60) {
    plantas.push({ x: i + 30, y: 290, ativa: true });
  }
}

function drawTrator(x, y) {
  fill(200, 0, 0);
  rect(x, y, 70, 30, 5);
  fill(0, 100, 200);
  rect(x + 20, y - 25, 30, 25, 3);
  fill(0);
  ellipse(x + 20, y + 30, 24);
  ellipse(x + 60, y + 30, 24);
  fill(220);
  ellipse(x + 20, y + 30, 10);
  ellipse(x + 60, y + 30, 10);
}

function cenaCaminho() {
  background(180, 220, 255);

  fill(100);
  rect(0, 250, width, 150);

  for (let i = 0; i < width; i += 40) {
    fill(255);
    rect(i, 325, 20, 5);
  }

  drawCaminhao(caminhaoX, 260);
  caminhaoX += 3;

  fill(255);
  textSize(18);
  text("O alimento viaja com cuidado até chegar a muitas mesas.", width / 2, 40);

  if (caminhaoX > width + 100) {
    tela = "cidade";
    tempo = millis();
  }
}

function drawCaminhao(x, y) {
  fill(50, 50, 180);
  rect(x, y, 100, 40, 5);
  fill(150);
  rect(x + 70, y - 20, 30, 20, 3);
  fill(0);
  ellipse(x + 20, y + 40, 24);
  ellipse(x + 80, y + 40, 24);
  fill(220);
  ellipse(x + 20, y + 40, 10);
  ellipse(x + 80, y + 40, 10);
}

function cenaCidade() {
  background(200, 200, 230);

  fill(70);
  rect(0, 300, width, 100);

  // Prédios
  let cores = [[160,160,180],[190,190,220],[120,120,150]];
  for (let i = 0; i < 4; i++) {
    let px = 100 + i * 130;
    let ph = 130 + i * 15;
    fill(cores[i % cores.length]);
    rect(px, 400 - ph, 80, ph);
    fill(255, 255, 200);
    for (let y = 400 - ph + 20; y < 400; y += 30) {
      rect(px + 15, y, 15, 20, 3);
      rect(px + 45, y, 15, 20, 3);
    }
  }

  // Feira separada
  let fx = 600, fy = 230;
  fill(255, 0, 0);
  rect(fx, fy, 120, 40, 5);
  fill(255);
  textSize(14);
  text("Feira do Produtor", fx + 60, fy - 5);

  drawPessoa(fx + 20, fy + 70);
  drawPessoa(fx + 50, fy + 70);
  drawPessoa(fx + 80, fy + 70);

  fill(255);
  textSize(18);
  text("Na cidade, o campo se transforma em alimento, cultura e união.", width / 2, 40);

  if (millis() - tempo > 5000) {
    tela = "festa";
    tempo = millis();
    botaoReiniciar = true;
  }
}

function drawPessoa(x, y) {
  fill(255, 224, 189);
  ellipse(x, y - 20, 20);
  fill(60, 100, 200);
  rect(x - 6, y - 10, 12, 20);
  fill(80);
  rect(x - 6, y + 10, 5, 15);
  rect(x + 1, y + 10, 5, 15);
  fill(0);
  ellipse(x, y - 30, 22, 10); // cabelo
}

function cenaFesta() {
  background(20, 20, 60);

  // Luzes coloridas
  for (let i = 0; i < 60; i++) {
    fill(random(255), random(255), random(255), 180);
    ellipse(random(width), random(200), random(10, 25));
  }

  // Bolo
  let boloX = width / 2, boloY = 280;
  fill(255, 182, 193);
  rect(boloX - 60, boloY, 120, 40, 10);
  fill(255, 105, 180);
  rect(boloX - 50, boloY - 30, 100, 30, 10);
  fill(255);
  textSize(12);
  textAlign(CENTER);
  text("Ribeirão Claro", boloX, boloY + 15);
  text("União Campo e Cidade", boloX, boloY + 30);

  // Pessoas do campo (à esquerda)
  for (let i = 0; i < 4; i++) {
    let x = 140 + i * 40;
    let yOffset = sin(frameCount * 0.2 + i) * 10;
    drawPessoaCampo(x, 330 + yOffset);
  }

  // Pessoas da cidade (à direita)
  for (let i = 0; i < 4; i++) {
    let x = 520 + i * 40;
    let yOffset = sin(frameCount * 0.2 + i + 3) * 10;
    drawPessoaCidade(x, 330 + yOffset);
  }

  // Título da festa
  fill(255);
  textSize(20);
  textAlign(CENTER);
  text("Celebração da Conexão!", width / 2, 40);
  textSize(16);
  text("O campo e a cidade comemoram juntos o fruto da união!", width / 2, 70);

  if (botaoReiniciar) {
    drawBotao(width / 2 - 60, 350, 120, 40, "Reiniciar");
  }
}
function drawPessoaCampo(x, y) {
  fill(255, 224, 189);
  ellipse(x, y - 20, 20); // rosto
  fill(100, 150, 100);
  rect(x - 6, y - 10, 12, 20); // corpo
  fill(80, 42, 42);
  rect(x - 6, y + 10, 5, 15); // perna esq
  rect(x + 1, y + 10, 5, 15); // perna dir
  fill(139, 69, 19);
  arc(x, y - 30, 26, 20, PI, TWO_PI); // chapéu de palha
}

function drawPessoaCidade(x, y) {
  fill(255, 224, 189);
  ellipse(x, y - 20, 20); // rosto
  fill(80, 80, 200);
  rect(x - 6, y - 10, 12, 20); // corpo
  fill(60);
  rect(x - 6, y + 10, 5, 15);
  rect(x + 1, y + 10, 5, 15);
  fill(0);
  ellipse(x, y - 30, 22, 10); // cabelo moderno
}
  background(20, 20, 60);

  for (let i = 0; i < 40; i++) {
    fill(random(255), random(255), random(255), 180);
    ellipse(random(width), random(200), random(10, 25));
  }

  fill(100);
  rect(300, 260, 200, 100, 5);
  fill(255);
  textAlign(CENTER);
  textSize(20);
  text("Celebração da Colheita e da União!", width / 2, 250);

  drawPessoa(340, 330);
  drawPessoa(400, 330);
  drawPessoa(460, 330);

  fill(255);
  textSize(18);
  text("Quando o campo encontra a cidade, nasce um futuro mais forte.", width / 2, 40);

  if (botaoReiniciar) {
    drawBotao(width / 2 - 60, 330, 120, 40, "Reiniciar");

}

function drawBotao(x, y, w, h, label) {
  if (mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
    fill(220);
  } else {
    fill(255);
  }
  rect(x, y, w, h, 10);
  fill(0);
  textSize(16);
  textAlign(CENTER, CENTER);
  text(label, x + w / 2, y + h / 2);
}

function mousePressed() {
  checarCliqueOuToque();
}
function touchStarted() {
  checarCliqueOuToque();
}
function checarCliqueOuToque() {
  if (tela === "inicio" && mouseX > btnX && mouseX < btnX + btnW && mouseY > btnY && mouseY < btnY + btnH) {
    tela = "campo";
    tempo = millis();
    tratorX = -80;
    iniciarPlantas();
  }

  if (botaoReiniciar && mouseX > width / 2 - 60 && mouseX < width / 2 + 60 && mouseY > 330 && mouseY < 370) {
    tela = "inicio";
    botaoReiniciar = false;
  }
}